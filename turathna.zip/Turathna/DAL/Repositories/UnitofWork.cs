﻿using Data;
using Interfaces;
using Models;
using Repositories;

public class UnitofWork : IUnitofWork
{
    private readonly DataBaseContext _context;

    public IRepository<Product> Products { get; }
    public IRepository<User> Users { get; }
    public IRepository<Cart> Cart { get; }
    public IRepository<Checkout> Checkout { get; }

    public UnitofWork(DataBaseContext context)
    {
        _context = context;
        Products = new Repository<Product>(_context);
        Users = new Repository<User>(_context);
        Cart = new Repository<Cart>(_context);
        Checkout = new Repository<Checkout>(_context);
    }

    public void Dispose()
    {
        _context.Dispose();
    }

    public int save()
    {
        return _context.SaveChanges();
    }

    public async Task<int> CompleteAsync()
    {
        return await _context.SaveChangesAsync();
    }
}
