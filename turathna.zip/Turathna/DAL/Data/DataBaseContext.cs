﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Data;

public class DataBaseContext:DbContext
{
    public DataBaseContext(DbContextOptions<DataBaseContext>options):base(options)
    {
        
    }
    public DbSet<Product> Products { get; set; }
    public DbSet<User> Users { get; set; }
    public DbSet<Cart> Cart { get; set; }
    public DbSet<Checkout> Checkout { get; set; }
}
