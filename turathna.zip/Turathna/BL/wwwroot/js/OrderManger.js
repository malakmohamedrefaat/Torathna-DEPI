document.addEventListener('DOMContentLoaded', function () {
    const tbody = document.querySelector('table tbody');

    function loadOrders() {
        const orders = JSON.parse(localStorage.getItem('orders')) || [];
        tbody.innerHTML = '';

        orders.forEach(order => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>#${order.id}</td>
                <td>${order.name}</td>
                <td>${order.date}</td>
                <td>${order.total}</td>
                <td>${order.status}</td>
                <td>
                    <button onclick="editOrder(${order.id})"><i class="fas fa-edit"></i> تعديل</button>
                    <button onclick="deleteOrder(${order.id})"><i class="fas fa-trash-alt"></i> حذف</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    window.editOrder = function (id) {
        localStorage.setItem('editOrderId', id);
        window.location.href = 'edit_order.html';
    }

    window.deleteOrder = function (id) {
        if (confirm(`هل أنت متأكد من حذف الطلب رقم ${id}؟`)) {
            let orders = JSON.parse(localStorage.getItem('orders')) || [];
            orders = orders.filter(order => order.id !== id);
            localStorage.setItem('orders', JSON.stringify(orders));
            loadOrders();
        }
    }

    // إن لم توجد بيانات، أضف بيانات تجريبية (للواجهة فقط)
    if (!localStorage.getItem('orders')) {
        const demoOrders = [
            { id: 12345, name: "أحمد علي", date: "2025-05-01", total: "250 ر.س", status: "قيد المعالجة" },
            { id: 12346, name: "فاطمة محمد", date: "2025-04-30", total: "400 ر.س", status: "تم الشحن" }
        ];
        localStorage.setItem('orders', JSON.stringify(demoOrders));
    }

    loadOrders();
});
