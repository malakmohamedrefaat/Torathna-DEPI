document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const index = localStorage.getItem('editIndex');
    const products = JSON.parse(localStorage.getItem('products')) || [];

    if (index !== null && products[index]) {
        document.getElementById('productName').value = products[index].name;
        document.getElementById('productDescription').value = products[index].description;
        document.getElementById('productPrice').value = products[index].price;
        document.getElementById('productQuantity').value = products[index].quantity;
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        products[index].name = document.getElementById('productName').value;
        products[index].description = document.getElementById('productDescription').value;
        products[index].price = parseFloat(document.getElementById('productPrice').value);
        products[index].quantity = parseInt(document.getElementById('productQuantity').value);

        localStorage.setItem('products', JSON.stringify(products));
        localStorage.removeItem('editIndex');
        window.location.href = 'product.html';
    });
});
