document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const id = parseInt(localStorage.getItem('editOrderId'));
    const orders = JSON.parse(localStorage.getItem('orders')) || [];

    const order = orders.find(o => o.id === id);
    if (order) {
        document.getElementById('orderId').value = id;
        document.getElementById('orderStatus').value = order.status;
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const newStatus = document.getElementById('orderStatus').value;

        const index = orders.findIndex(o => o.id === id);
        if (index !== -1) {
            orders[index].status = newStatus;
            localStorage.setItem('orders', JSON.stringify(orders));
        }

        localStorage.removeItem('editOrderId');
        window.location.href = 'order.html';
    });
});
