document.addEventListener('DOMContentLoaded', function () {
    const paymentOptions = document.querySelectorAll('.payment-option');
    const completePaymentBtn = document.getElementById('complete-payment-btn');

    if (completePaymentBtn) {
        completePaymentBtn.addEventListener('click', function () {
            window.location.href = "ShippingInfo.html";
        });
    }

    paymentOptions.forEach(option => {
        const header = option.querySelector('.option-header');
        const details = option.querySelector('.payment-details');

        header.addEventListener('click', function () {
            // Close all other open details
            paymentOptions.forEach(otherOption => {
                if (otherOption !== option && otherOption.classList.contains('active')) {
                    otherOption.classList.remove('active');
                    otherOption.querySelector('.payment-details').style.display = 'none';
                }
            });

            // Toggle the current option
            option.classList.toggle('active');
            details.style.display = option.classList.contains('active') ? 'block' : 'none';
        });
    });

    // Populate expiry month and year dropdowns (basic example)
    const expiryMonthSelect = document.getElementById('expiry-month');
    const expiryYearSelect = document.getElementById('expiry-year');
    const months = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
    const currentYear = new Date().getFullYear();

    months.forEach((month, index) => {
        const option = document.createElement('option');
        option.value = index + 1;
        option.textContent = month;
        expiryMonthSelect.appendChild(option);
    });

    for (let i = 0; i < 10; i++) { // Add next 10 years
        const year = currentYear + i;
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        expiryYearSelect.appendChild(option);
    }
});
