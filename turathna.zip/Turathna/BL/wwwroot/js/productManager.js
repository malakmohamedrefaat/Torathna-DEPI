document.addEventListener('DOMContentLoaded', function () {
    const tableBody = document.querySelector('table tbody');

    function loadProducts() {
        tableBody.innerHTML = '';
        const products = JSON.parse(localStorage.getItem('products')) || [];

        products.forEach((product, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${product.name}</td>
                <td>${product.description}</td>
                <td>${product.price} ر.س</td>
                <td>${product.quantity}</td>
                <td>
                    <button onclick="editProduct(${index})" style="background-color:#5c4011;color:white;">تعديل</button>
                    <button onclick="deleteProduct(${index})" style="background-color:#8b0000;color:white;">حذف</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    window.deleteProduct = function (index) {
        const products = JSON.parse(localStorage.getItem('products')) || [];
        if (confirm(`هل أنت متأكد من حذف المنتج "${products[index].name}"؟`)) {
            products.splice(index, 1);
            localStorage.setItem('products', JSON.stringify(products));
            loadProducts();
        }
    }

    window.editProduct = function (index) {
        localStorage.setItem('editIndex', index);
        window.location.href = 'update_product.html';
    }

    window.addProduct = function () {
        window.location.href = 'add_product.html';
    }

    loadProducts();
});
