// Adding an event listener to the "Add to Cart" buttons
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function () {
        const productId = this.getAttribute('data-product-id');
        const productName = this.getAttribute('data-product-name');
        const productPrice = this.getAttribute('data-product-price');
        const productImage = this.getAttribute('data-product-image');

        // Retrieve cart from localStorage, or initialize an empty array if not found
        let cart = JSON.parse(localStorage.getItem('cart')) || [];

        // Check if the product is already in the cart
        let existingProduct = cart.find(item => item.id == productId);

        if (existingProduct) {
            // If the product already exists in the cart, increase the quantity
            existingProduct.quantity += 1;
        } else {
            // If it's a new product, add it to the cart
            cart.push({
                id: productId,
                name: productName,
                price: productPrice,
                image: productImage,
                quantity: 1
            });
        }

        // Save the updated cart back to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));

        // Update the cart count displayed in the nav
        updateCartCount();
    });
});

// Function to update the cart count in the nav
function updateCartCount() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    document.getElementById('cart-count').textContent = `(${cart.reduce((sum, item) => sum + item.quantity, 0)})`;
}

// Call the function to update the cart count when the page loads
updateCartCount();

// Add an event listener for when the user clicks on "سلة التسوق" to open the cart page
document.getElementById('cart-count').addEventListener('click', function () {
    window.location.href = '@Url.Action("Cart", "Home")';  // Redirect to the cart page
});
