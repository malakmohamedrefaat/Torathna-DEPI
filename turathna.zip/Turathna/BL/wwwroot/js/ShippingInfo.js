function trackOrder() {
    const trackingNumberInput = document.getElementById('tracking-number');
    const trackingStatusDiv = document.getElementById('tracking-status');
    const trackingNumber = trackingNumberInput.value.trim();

    if (trackingNumber) {
        // In a real application, you would make an API call here
        // to get the actual tracking status.
        // For this example, we'll just simulate a response.
        const statusMessages = [
            "تم استلام طلبك.",
            "طلبك قيد المعالجة.",
            "تم شحن طلبك.",
            "طلبك في طريقه للتسليم.",
            "تم تسليم طلبك بنجاح."
        ];
        const randomIndex = Math.floor(Math.random() * statusMessages.length);
        trackingStatusDiv.textContent = `حالة التتبع لرقم ${trackingNumber}: ${statusMessages[randomIndex]}`;
    } else {
        trackingStatusDiv.textContent = "يرجى إدخال رقم التتبع.";
    }
}