document.addEventListener('DOMContentLoaded', function () {
    // 🟡 Mock data - Replace later with fetch from API
    const data = {
        productCount: 120,
        customerCount: 45,
        orderCount: 18,
        revenueTotal: '25,000 ر.س',
        orders: [
            { id: '#12345', customer: 'أحمد محمد', date: '2025-05-01', total: '500 ر.س', status: 'قيد المعالجة' },
            { id: '#12346', customer: 'سارة علي', date: '2025-05-02', total: '750 ر.س', status: 'تم الشحن' }
        ],
        customerStats: {
            new: 80,
            returning: 20
        }
    };

    // 🟢 Fill summary values
    document.getElementById('product-count').textContent = data.productCount;
    document.getElementById('customer-count').textContent = data.customerCount;
    document.getElementById('order-count').textContent = data.orderCount;
    document.getElementById('revenue-total').textContent = data.revenueTotal;

    // 🟢 Fill order table
    const ordersBody = document.getElementById('orders-body');
    ordersBody.innerHTML = '';
    data.orders.forEach(order => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${order.id}</td>
            <td>${order.customer}</td>
            <td>${order.date}</td>
            <td>${order.total}</td>
            <td>${order.status}</td>
        `;
        ordersBody.appendChild(tr);
    });

    // 🟢 Customer chart
    const ctx = document.getElementById('customer-chart');
    if (ctx) {
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['عملاء جدد', 'عملاء حاليين'],
                datasets: [{
                    data: [data.customerStats.new, data.customerStats.returning],
                    backgroundColor: ['#b8860b', '#d4a373'],
                    hoverOffset: 4
                }]
            }
        });
    }
});
