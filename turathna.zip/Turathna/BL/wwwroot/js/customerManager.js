document.addEventListener('DOMContentLoaded', function () {
    const tbody = document.getElementById('customer-list');

    function loadCustomers() {
        const customers = JSON.parse(localStorage.getItem('customers')) || [];
        tbody.innerHTML = '';

        customers.forEach(customer => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${customer.id}</td>
                <td>${customer.name}</td>
                <td>${customer.email}</td>
                <td>${customer.phone}</td>
                <td>
                    <button onclick="deleteCustomer(${customer.id})"><i class="fas fa-trash-alt"></i> حذف</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    window.deleteCustomer = function (id) {
        if (confirm(`هل أنت متأكد من حذف العميل رقم ${id}؟`)) {
            let customers = JSON.parse(localStorage.getItem('customers')) || [];
            customers = customers.filter(c => c.id !== id);
            localStorage.setItem('customers', JSON.stringify(customers));
            loadCustomers();
        }
    }

    // بيانات تجريبية لمرة واحدة
    if (!localStorage.getItem('customers')) {
        const demoCustomers = [
            { id: 1, name: "أحمد علي", email: "ahmad@example.com", phone: "0551234567" },
            { id: 2, name: "فاطمة محمد", email: "fatima@example.com", phone: "0567654321" }
        ];
        localStorage.setItem('customers', JSON.stringify(demoCustomers));
    }

    loadCustomers();
});
