document.addEventListener('DOMContentLoaded', function () {
    // ... باقي الكود الموجود في cart.js ...

    const checkoutButton = document.querySelector('.continue-to-payment-button');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function () {
            // هنا يمكنك تنفيذ أي عمليات تحقق أو تجهيز للبيانات قبل الانتقال
            window.location.href = 'Pay.html'; // استبدل 'order.html' باسم صفحتك
        });
    }

    // ... باقي الكود الموجود في cart.js ...
});