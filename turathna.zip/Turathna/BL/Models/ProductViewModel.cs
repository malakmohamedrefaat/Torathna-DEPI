﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace PL.Models;

public class ProductViewModel
{
    [Display(Name = "صورة المنتج")]
    public IFormFile ProductImage { get; set; }

    [Required(ErrorMessage = "اسم المنتج مطلوب")]
    [Display(Name = "اسم المنتج")]
    public string Name { get; set; }

    [Required(ErrorMessage = "وصف المنتج مطلوب")]
    [Display(Name = "وصف المنتج")]
    public string Description { get; set; }

    [Required(ErrorMessage = "السعر مطلوب")]
    [Range(0.01, double.MaxValue, ErrorMessage = "يجب إدخال سعر صالح")]
    [Display(Name = "السعر (ر.س)")]
    public string Price { get; set; }

    [Required(ErrorMessage = "الكمية مطلوبة")]
    [Range(1, int.MaxValue, ErrorMessage = "الكمية يجب أن تكون على الأقل 1")]
    [Display(Name = "الكمية")]
    public int Quantity { get; set; }
}
