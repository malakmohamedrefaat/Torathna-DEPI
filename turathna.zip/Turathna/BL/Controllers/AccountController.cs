﻿using Data;
using Microsoft.AspNetCore.Mvc;
using Models;
using BCrypt.Net;
using Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

public class AccountController : Controller
{
    private readonly IUnitofWork _unitOfWork;

    public AccountController(IUnitofWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    // GET: /Account/SignUp
    [HttpGet]
    public IActionResult SignUp()
    {
        return View();
    }

    // POST: /Account/SignUp
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SignUp(User model)
    {
        if (ModelState.IsValid)
        {
            // Hash the password
            model.Password = BCrypt.Net.BCrypt.HashPassword(model.Password);

            _unitOfWork.Users.Add(model);
            await _unitOfWork.CompleteAsync();

            // Redirect to login page after successful registration
            return RedirectToAction("Login", "Account");
        }

        return View(model);
    }

    // GET: /Account/Login
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    // POST: /Account/Login
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string email, string password)
    {
        var user = await _unitOfWork.Users.FirstOrDefaultAsync(u => u.Email == email);

        if (user != null && BCrypt.Net.BCrypt.Verify(password, user.Password))
        {
            // Set session or authentication token here
            HttpContext.Session.SetString("UserName", user.FirstName); // Store user name in session
            HttpContext.Session.SetString("UserRole", user.AccountType); // Store the role (user/admin)

            // Redirect to the home page based on role
            if (user.AccountType == "admin")
            {
                return RedirectToAction("Index", "Dashboard"); // Redirect to admin dashboard if admin
            }
            else if (user.AccountType == "user")
            {
                return RedirectToAction("Index", "Home"); // Redirect to regular home page if user
            }
            else
            {
                return RedirectToAction("IndexNotLogedIn", "Home");
            }
        }
        else
        {
            // Add model error when email or password is incorrect
            ModelState.AddModelError("", "البريد الإلكتروني أو كلمة المرور غير صحيحة.");
        }

        return View();
    }

    // GET: /Account/ResetPassword
    [HttpGet]
    public IActionResult ResetPassword(string email)
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ResetPassword(string email, string password)
    {
        // Fetch the user based on the email
        var user = await _unitOfWork.Users.FirstOrDefaultAsync(u => u.Email == email);

        if (user != null)
        {
            // Hash the new password before saving to database
            user.Password = BCrypt.Net.BCrypt.HashPassword(password);

            // Update the user in the database
            _unitOfWork.Users.Update(user);
            await _unitOfWork.CompleteAsync();

            // Redirect to login page after password is updated
            return RedirectToAction("Login", "Account");
        }

        // If user not found, show error message
        ModelState.AddModelError("", "البريد الإلكتروني غير موجود.");
        return View();
    }


    // Logout functionality
    public IActionResult Logout()
    {
        HttpContext.Session.Clear(); // Clear session data
        return RedirectToAction("Login", "Account"); // Redirect to the login page
    }

    // Dashboard/Home for users/admins
    public IActionResult Index()
    {
        ViewBag.UserName = HttpContext.Session.GetString("UserName");
        return View();
    }
}
