﻿using Microsoft.AspNetCore.Mvc;
using Interfaces;
using Models;

namespace PL.Controllers
{
    public class DashboardController : Controller
    {
        private readonly IUnitofWork _unitOfWork;

        public DashboardController(IUnitofWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {
            // Fetch the necessary data for the dashboard
            var totalProducts = _unitOfWork.Products.GetAll().Count();  // Total number of products
            var totalCustomers = _unitOfWork.Users.GetAll().Count();  // Total number of customers
            //var totalOrders = _unitOfWork.Orders.GetAll().Count();  // Total number of orders
            //var totalRevenue = _unitOfWork.Orders.GetAll().Sum(o => o.TotalAmount);  // Total revenue from all orders

            // Pass the data to the view via ViewBag
            ViewBag.TotalProducts = totalProducts;
            ViewBag.TotalCustomers = totalCustomers;
            //ViewBag.TotalOrders = totalOrders;
            //ViewBag.TotalRevenue = totalRevenue;
            string userName = HttpContext.Session.GetString("UserName");

            // Pass the session data to the view via ViewBag
            ViewBag.UserName = userName;
            // Return the admin dashboard view
            return View();
        }
        // Action to return the clients page
        public IActionResult Users()
        {
            var clients = _unitOfWork.Users.GetAll(); // Fetch clients from DB using IUnitOfWork
            return View(clients);
        }
    }
}
