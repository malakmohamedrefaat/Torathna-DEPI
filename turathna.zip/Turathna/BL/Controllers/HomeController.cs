﻿using Microsoft.AspNetCore.Mvc;
using Interfaces;
using Microsoft.EntityFrameworkCore;
using Models;

namespace PL.Controllers
{
    public class HomeController : Controller
    {
        private readonly IUnitofWork _unitOfWork;

        public HomeController(IUnitofWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {
            var products = _unitOfWork.Products.GetAll();
            ViewBag.UserName = HttpContext.Session.GetString("UserName");
            return View(products);
        }

        public IActionResult IndexNotLogedIn()
        {
            var products = _unitOfWork.Products.GetAll();
            ViewBag.UserName = HttpContext.Session.GetString("UserName");
            return View(products);
        }

        [HttpGet]
        public IActionResult Cart()
        {
            var userId = User.Identity.IsAuthenticated ? User.Identity.Name : "Guest";

            var cartItems = _unitOfWork.Cart
                .GetAllIncluding(c => c.Product)
                .Where(c => c.UserId == userId)
                .ToList();

            return View(cartItems);
        }

        [HttpPost]
        public async Task<IActionResult> AddToCart(int productId)
        {
            var userId = User.Identity.IsAuthenticated ? User.Identity.Name : "Guest";

            var existingItem = await _unitOfWork.Cart
                .FirstOrDefaultAsync(c => c.ProductId == productId && c.UserId == userId);

            if (existingItem != null)
            {
                existingItem.Quantity += 1;
            }
            else
            {
                await _unitOfWork.Cart.AddAsync(new Cart
                {
                    ProductId = productId,
                    UserId = userId,
                    Quantity = 1,
                    DateAdded = DateTime.Now
                });
            }

            await _unitOfWork.CompleteAsync();

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult IncreaseQuantity(int cartId)
        {
            var item = _unitOfWork.Cart.GetById(cartId);
            if (item != null)
            {
                item.Quantity += 1;
                _unitOfWork.save();
            }
            return RedirectToAction("Cart");
        }

        [HttpPost]
        public IActionResult DecreaseQuantity(int cartId)
        {
            var item = _unitOfWork.Cart.GetById(cartId);
            if (item != null && item.Quantity > 1)
            {
                item.Quantity -= 1;
                _unitOfWork.save();
            }
            return RedirectToAction("Cart");
        }

        [HttpPost]
        public IActionResult RemoveFromCart(int cartId)
        {
            var item = _unitOfWork.Cart.GetById(cartId);
            if (item != null)
            {
                _unitOfWork.Cart.Remove(item);
                _unitOfWork.save();
            }
            return RedirectToAction("Cart");
        }
        [HttpGet]
        public IActionResult Checkout()
        {
            var userName = HttpContext.Session.GetString("UserName");

            if (string.IsNullOrEmpty(userName))
            {
                return RedirectToAction("Login", "Account");
            }

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmOrder(Checkout model)
        {
            var userName = HttpContext.Session.GetString("UserName");

            if (string.IsNullOrEmpty(userName))
            {
                return RedirectToAction("Login", "Account");
            }

            // ✅ احضر عناصر السلة الخاصة بالمستخدم
            var cartItems = _unitOfWork.Cart
                .GetAll()
                .Where(c => c.UserId == userName)
                .ToList();

            if (!cartItems.Any())
            {
                TempData["Error"] = "سلة التسوق فارغة. لا يمكن تأكيد الطلب.";
                return RedirectToAction("Cart");
            }

            // ✅ حفظ الطلب في جدول Checkout
            model.Status = "قيد المعالجة";
            await _unitOfWork.Checkout.AddAsync(model);

            // ✅ حذف جميع عناصر السلة
            foreach (var item in cartItems)
            {
                _unitOfWork.Cart.Remove(item);
            }

            await _unitOfWork.CompleteAsync();

            return RedirectToAction("Index");
        }


    }
}
