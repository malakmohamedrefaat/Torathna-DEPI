document.addEventListener('DOMContentLoaded', function () {
    const cartCountSpan = document.getElementById('cart-count');
    const cartItemsList = document.getElementById('cart-items-list');
    const subtotalElement = document.getElementById('subtotal');
    const totalElement = document.getElementById('total');
    const shippingElement = document.getElementById('shipping');
    const emptyCartMessage = document.querySelector('.empty-cart-message');

    function loadCart() {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        cartItemsList.innerHTML = '';
        let subtotal = 0;

        if (cart.length === 0) {
            emptyCartMessage.style.display = 'block';
        } else {
            emptyCartMessage.style.display = 'none';
        }

        cart.forEach((item, index) => {
            const li = document.createElement('li');
            li.className = 'cart-item';
            li.innerHTML = `
                <div class="item-details">
                    <h3>${item.name}</h3>
                    <div class="item-price">${item.price} جنيه</div>
                    <div class="quantity-controls">
                        <button onclick="updateQuantity(${index}, -1)">-</button>
                        <span class="quantity">${item.quantity}</span>
                        <button onclick="updateQuantity(${index}, 1)">+</button>
                    </div>
                    <button class="remove-item" onclick="removeFromCart(${index})">إزالة</button>
                </div>
            `;
            cartItemsList.appendChild(li);
            subtotal += item.price * item.quantity;
        });

        cartCountSpan.textContent = `(${cart.reduce((sum, item) => sum + item.quantity, 0)})`;
        subtotalElement.textContent = `${subtotal} جنيه`;
        shippingElement.textContent = 'سيتم تحديده لاحقًا';
        totalElement.textContent = `${subtotal} جنيه`;
    }

    window.updateQuantity = function (index, change) {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        if (cart[index]) {
            cart[index].quantity += change;
            if (cart[index].quantity < 1) cart[index].quantity = 1;
            localStorage.setItem('cart', JSON.stringify(cart));
            loadCart();
        }
    };

    window.removeFromCart = function (index) {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        cart.splice(index, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCart();
    };

    loadCart();

    const checkoutButton = document.querySelector('.checkout-button');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function () {
            window.location.href = 'ShippingDetails.html';
        });
    }
});
