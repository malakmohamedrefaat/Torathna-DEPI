document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const name = document.getElementById('productName').value;
        const description = document.getElementById('productDescription').value;
        const price = parseFloat(document.getElementById('productPrice').value);
        const quantity = parseInt(document.getElementById('productQuantity').value);

        let products = JSON.parse(localStorage.getItem('products')) || [];
        products.push({ name, description, price, quantity });

        localStorage.setItem('products', JSON.stringify(products));
        window.location.href = 'product.html';
    });
});
