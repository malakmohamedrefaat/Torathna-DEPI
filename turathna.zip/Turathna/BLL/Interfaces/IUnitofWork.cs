﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces;

public interface IUnitofWork:IDisposable
{
    public IRepository <Product> Products { get; }
    public IRepository<User> Users { get; }
    public IRepository<Cart> Cart { get; }
    public IRepository<Checkout> Checkout { get; }
    Task<int> CompleteAsync();

    int save();
}
