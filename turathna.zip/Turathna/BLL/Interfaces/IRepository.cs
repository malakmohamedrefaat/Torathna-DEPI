﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces;

public interface IRepository<T>
{
    IEnumerable<T> GetAll();
    T GetById(int id);
    void Add(T entity);
    void Update(T entity);
    void Delete(T entity);
    // Add this method
    Task<T> FirstOrDefaultAsync(Expression<Func<T, bool>> predicate);
    IQueryable<T> GetAllIncluding(params Expression<Func<T, object>>[] includeProperties);
    Task AddAsync(T entity);
    void Remove(T entity);
}
